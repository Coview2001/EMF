import React from 'react';

const PDFReport: React.FC = () => {
  return (
    <div>
      <head>
        <title>PDF Report</title>
      </head>
      <body>
        <form id="form1">
          <div>
          </div>
        </form>
      </body>
    </div>
  );
};

export default PDFReport;
